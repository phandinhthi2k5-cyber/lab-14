Họ và tên: kim ngọc bắc
MSSV: 20230178
Bài tập: Lab 14 - PHP CRUD, Pagination, Upload, Flash Message

--- HƯỚNG DẪN CÀI ĐẶT ---
1. Import file 'db.sql' vào phpMyAdmin (tên database: demo_php).
2. Cấu hình kết nối database:
   - Mở file: libs/helper.php
   - Kiểm tra thông tin: host, dbname, username, password.
3. Chạy dự án:
   - Truy cập: http://localhost/bai_tap_php/index.php

--- CÔNG NGHỆ SỬ DỤNG ---
- PHP thuần (Mô hình MVC đơn giản).
- Giao diện: SB Admin 2 (Bootstrap 4).
- Database: MySQL.